# Interactive 3D Nuclear Pore Complex

A browser-based conceptual visualization of the nuclear pore complex (NPC), nucleoporins, and bidirectional transport. It uses Three.js and requires no build step.

## Files

- `index.html` – complete application
- `LICENSE` – MIT license

## Run locally

Because the project uses JavaScript modules, serve it through a local web server rather than opening the file directly.

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `README.md`, and `LICENSE` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

## Important scientific note

This is an educational and hypothesis-visualization model, not a molecular-resolution reconstruction, validated simulation, diagnostic tool, or clinical risk model. The displayed scores are illustrative. Add peer-reviewed references before presenting biological or disease claims as established findings.

## Dependency

Three.js 0.170.0 is loaded from the unpkg CDN, so internet access is required when the page opens.
